import * as T from 'three';
import {EffectComposer} from 'three/addons/postprocessing/EffectComposer.js';
import {RenderPass} from 'three/addons/postprocessing/RenderPass.js';
import {GTAOPass} from 'three/addons/postprocessing/GTAOPass.js';
import {UnrealBloomPass} from 'three/addons/postprocessing/UnrealBloomPass.js';
import {OutputPass} from 'three/addons/postprocessing/OutputPass.js';
import {ShaderPass} from 'three/addons/postprocessing/ShaderPass.js';
import {FXAAShader} from 'three/addons/shaders/FXAAShader.js';
// Exclude glass, the panorama and invisible pointer targets from the AO depth
// buffer. Overriding their materials would otherwise create phantom dark walls.
class ContactPass extends GTAOPass{
 _overrideVisibility(){super._overrideVisibility();this.scene.traverse(o=>{if(o.isMesh&&o.visible&&((o.material?.transparent&&o.name!=='Photographic near ground')||o.material?.visible===false||o.material?.depthWrite===false)){o.visible=false;this._visibilityCache.push(o);}});}
}
export function createPhotography(renderer,scene,camera){
 const composer=new EffectComposer(renderer);composer.setPixelRatio(1);
 const color=new RenderPass(scene,camera);composer.addPass(color);
 const contact=new ContactPass(scene,camera,512,512,undefined,{radius:.65,thickness:1,distanceFallOff:.8,samples:12});contact.blendIntensity=.42;composer.addPass(contact);
 const glow=new UnrealBloomPass(new T.Vector2(512,512),.18,.45,1.4);glow.enabled=false;composer.addPass(glow);
 composer.addPass(new OutputPass());
 const aa=new ShaderPass(FXAAShader);composer.addPass(aa);
 const lens=new ShaderPass({uniforms:{tDiffuse:{value:null}},vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',fragmentShader:'uniform sampler2D tDiffuse;varying vec2 vUv;void main(){vec4 c=texture2D(tDiffuse,vUv);vec2 p=vUv-.5;float vignette=1.0-.15*dot(p,p);c.rgb=clamp((c.rgb-.5)*1.045+.5,0.0,1.0)*vignette;gl_FragColor=c;}'});composer.addPass(lens);
 let enabled=true;
 function resize(w,h){const ratio=Math.min(1.5,2200/w),width=Math.max(1,Math.round(w*ratio)),height=Math.max(1,Math.round(h*ratio));composer.setSize(width,height);contact.setSize(Math.max(1,Math.round(width*.65)),Math.max(1,Math.round(height*.65)));aa.uniforms.resolution.value.set(1/width,1/height);}
 return {night(v){glow.enabled=v;},set(v){enabled=v;},resize,render(cam,plan=false){if(enabled&&!plan){color.camera=contact.camera=cam;composer.render();}else renderer.render(scene,cam);},dispose(){composer.dispose();for(const pass of composer.passes)pass.dispose?.();}};
}
