export const VERSION=1;
export const WALLS=['open','window','canvas','down'];
export const LABELS={open:'Öppet brätte',window:'WallFlex fönster',canvas:'WallFlex duk',down:'Nedfälld tältduk'};
export const ITEMS={
 table200:{name:'Fällbart bord 200',sku:'41006',l:1.98,w:.70,h:.73,kind:'table',image:'reference-table200.png',handle:'collapsible-table-200-oil-treated'},
 bench200:{name:'Fällbar bänk 200',sku:'41005',l:1.98,w:.23,h:.44,kind:'bench',image:'reference-bench200.png',handle:'collapsible-bench-200-oil-treated'},
 table150:{name:'Fällbart bord 150',sku:'41053',l:1.55,w:.70,h:.73,kind:'table',image:'reference-table150.webp',handle:'collapsible-table-150-oil-treated'},
 bench150:{name:'Fällbar bänk 150',sku:'41052',l:1.55,w:.23,h:.44,kind:'bench',image:'reference-bench150.webp',handle:'collapsible-bench-150-oil-treated'},
 bamse:{name:'Bamse max',sku:'40005',l:1.5,w:1.2,h:.8,kind:'fire',illustrative:true,image:'reference-bamse-max.webp',handle:'bamse-max'}
};
export function uid(){return 'p'+Math.random().toString(36).slice(2,10)}
export function furniture(type,x,z,rotation=0){return {id:uid(),type,x,z,rotation}}
export function preset(name){let f=[];if(name==='empty')return f;let points=name==='dinner'?[[-1.65,-1.4],[1.65,-1.4],[-1.65,1.4],[1.65,1.4]]:[[-1.65,0],[1.65,0]];for(const [x,z]of points){f.push(furniture('table200',x,z),furniture('bench200',x,z-.66),furniture('bench200',x,z+.66));}return f}
export function defaultState(){return {version:VERSION,fabric:'beige',walls:['open','open','open','window','window','window','open','open','open'],doors:Array(9).fill(false),floor:true,lights:true,items:preset('dinner')}}
export function normalize(input){
 if(!input||input.version!==VERSION||!Array.isArray(input.walls)||input.walls.length!==9||input.walls.some(x=>!WALLS.includes(x)))throw Error('Filen innehåller inte en giltig Stratus 72-konfiguration.');
 if(!['beige','white'].includes(input.fabric)||!Array.isArray(input.items)||input.items.length>90)throw Error('Ogiltig färg eller för många möbler.');
 const ids=new Set();const items=input.items.map(o=>{if(!o||(typeof o.type!=='string'||!Object.hasOwn(ITEMS,o.type))||typeof o.id!=='string'||!/^[a-zA-Z0-9_-]{1,32}$/.test(o.id)||ids.has(o.id)||![o.x,o.z,o.rotation].every(Number.isFinite)||Math.abs(o.x)>15||Math.abs(o.z)>15||Math.abs(o.rotation)>3600)throw Error('En möbel har ogiltiga mått eller koordinater.');ids.add(o.id);return {id:o.id,type:o.type,x:o.x,z:o.z,rotation:((o.rotation%360)+360)%360}});
 return {version:VERSION,fabric:input.fabric,walls:[...input.walls],doors:Array.from({length:9},(_,i)=>Boolean(input.doors?.[i])&&['window','canvas'].includes(input.walls[i])),floor:Boolean(input.floor),lights:Boolean(input.lights),items};
}
export function bayAngle(i){return i*Math.PI*2/9-Math.PI/2}
export function corners(o,pad=0){const p=ITEMS[o.type],r=o.rotation*Math.PI/180,c=Math.cos(r),s=Math.sin(r);return [[-1,-1],[1,-1],[1,1],[-1,1]].map(([a,b])=>{let x=a*(p.l/2+pad),z=b*(p.w/2+pad);return{x:o.x+x*c-z*s,z:o.z+x*s+z*c}})}
export function overlaps(a,b){const aa=corners(a,.025),bb=corners(b,.025);for(const ps of[aa,bb])for(let i=0;i<4;i++){const j=(i+1)%4,axis={x:-(ps[j].z-ps[i].z),z:ps[j].x-ps[i].x};const proj=p=>p.map(v=>v.x*axis.x+v.z*axis.z);const x=proj(aa),y=proj(bb);if(Math.max(...x)<=Math.min(...y)||Math.max(...y)<=Math.min(...x))return false;}return true}
export function issues(s){const out=[];for(const o of s.items){if(corners(o).some(p=>Math.hypot(p.x,p.z)>4.75))out.push({ids:[o.id],text:ITEMS[o.type].name+': kontrollera plats vid den sluttande duken och stommen.'});}for(let i=0;i<s.items.length;i++)for(let j=i+1;j<s.items.length;j++)if(overlaps(s.items[i],s.items[j]))out.push({ids:[s.items[i].id,s.items[j].id],text:'Två möbler överlappar varandra.'});return out}
export function bill(s){const result=[{name:'Stratus 72 · '+(s.fabric==='white'?'naturvit':'beige'),qty:1,sku:null,note:'Väv och offert bekräftas av Tentipi'}];for(const k of['window','canvas']){const n=s.walls.filter(x=>x===k).length;if(n)result.push({name:LABELS[k]+' · enkelvägg',qty:n,sku:null,note:'Väggmått, stöd och komponentutförande bekräftas'})}
 let boundaries=0;for(let i=0;i<9;i++){const a=['window','canvas'].includes(s.walls[i]),b=['window','canvas'].includes(s.walls[(i+1)%9]);if(a!==b)boundaries++}if(boundaries)result.push({name:'WallFlex ändutfyllnad · indikativt behov',qty:boundaries,sku:null,note:'Tentipi verifierar rätt ändstycken, infästning och antal'});
 for(const [type,p]of Object.entries(ITEMS)){const n=s.items.filter(o=>o.type===type).length;if(n)result.push({name:p.name,qty:n,sku:p.sku,note:p.illustrative?'Angivna mått 150 × 120 × 80 cm; detaljgeometri och användning bekräftas':''})}
 if(s.floor)result.push({name:'Eventmatta Sand · 2 × 10,5 m',qty:5,sku:'43052',note:'Rekommenderat grundpaket för Stratus 72, ej utökat brätte'});
 if(s.lights)result.push({name:'TT Ljusslingesystem · 9 × 8 m',qty:1,sku:'42003',note:'Tillgänglighet bekräftas'},{name:'TT strömadapter/dimmer EU',qty:1,sku:'42004',note:'Krävs för vald ljusslinga'});return result}
export function textSummary(s,url=''){const n=issues(s).length;return ['TENTIPI · STRATUS 72 / WALLFLEX','Konfigurationsförfrågan · ej bindande order','',...bill(s).map(x=>`${x.qty} × ${x.name}${x.sku?' · art. '+x.sku:''}${x.note?' ('+x.note+')':''}`),'','SEKTIONER (numrering enligt planvyn)',...s.walls.map((x,i)=>`${i+1}: ${LABELS[x]}${s.doors[i]?' · mittparti öppet':''}`),'','MÖBLERING (meter från tältcentrum)',...s.items.map(x=>`${ITEMS[x.type].name}: x ${x.x.toFixed(2)}, z ${x.z.toFixed(2)}, rotation ${x.rotation}°`),'',n?`${n} placeringspunkter behöver granskas.`:'Inga upptäckta möbelöverlappningar.','Yttergeometri och fria passager är illustrativa. Slutlig komponentlista, pris, förankring och användning godkänns av Tentipi.',url?'Öppna konfigurationen: '+url:''].join('\n')}
export function encode(s){return btoa(String.fromCharCode(...new TextEncoder().encode(JSON.stringify(normalize(s))))).replaceAll('+','-').replaceAll('/','_').replaceAll('=','')}
export function decode(str){if(typeof str!=='string'||str.length>24000)throw Error('Delningslänken är för stor.');return normalize(JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(str.replaceAll('-','+').replaceAll('_','/')),c=>c.charCodeAt(0)))))}
