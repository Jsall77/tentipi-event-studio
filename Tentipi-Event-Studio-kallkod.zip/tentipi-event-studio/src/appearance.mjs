// Procedural, seamless PBR surfaces. These describe appearance only; no product
// dimensions, canopy vertices, furniture footprints or catalogue values change.
export function createAppearance(T,renderer){
 const anisotropy=Math.min(12,renderer.capabilities.getMaxAnisotropy());
 function surface(kind){
  const size=1024,c=document.createElement('canvas');c.width=c.height=size;const ctx=c.getContext('2d'),img=ctx.createImageData(size,size),height=ctx.createImageData(size,size);let seed=173;
  const rnd=()=>((seed=(seed*16807)%2147483647)-1)/2147483646;
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
   const u=x/size,v=y/size,t=Math.PI*2,n=rnd()-.5;let value,h;
   if(kind==='wood'){
    const warp=2.5*Math.sin(v*t)+.8*Math.sin(v*t*3),grain=Math.sin(u*t*73+warp)+.38*Math.sin(u*t*171+warp*2),broad=Math.sin(u*t*7+warp*.3);
    const knot=Math.exp(-((u-.43)**2*130+(v-.6)**2*180));
    value=210+grain*12+broad*8+n*5-knot*35;h=128+grain*20+broad*7;
   }else{
    const weave=Math.sin(x*Math.PI*.5)*Math.sin(y*Math.PI*.5),fold=Math.sin(u*t*5+1.5*Math.sin(v*t*2))*.5+Math.sin(v*t*11+.6*Math.sin(u*t*3))*.22;
    value=239+fold*3+n*3+weave*1.3;h=128+fold*41+weave*7+n*3;
   }
   const i=(y*size+x)*4;img.data[i]=value;img.data[i+1]=value*(kind==='wood'?.9:.994);img.data[i+2]=value*(kind==='wood'?.74:.98);img.data[i+3]=255;height.data[i]=height.data[i+1]=height.data[i+2]=h;height.data[i+3]=255;
  }
  ctx.putImageData(img,0,0);const map=new T.CanvasTexture(c);map.colorSpace=T.SRGBColorSpace;
  const b=document.createElement('canvas');b.width=b.height=size;b.getContext('2d').putImageData(height,0,0);const bump=new T.CanvasTexture(b);
  for(const tex of[map,bump]){tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.anisotropy=anisotropy;tex.repeat.set(kind==='wood'?1:.4,kind==='wood'?2:.4);}
  return {map,bump};
 }
 const canvas=surface('canvas'),timber=surface('wood');
 const wood=new T.MeshStandardMaterial({map:timber.map,bumpMap:timber.bump,bumpScale:.006,color:0xd4bb90,roughness:.7,dithering:true});
 const furnitureWood=new T.MeshPhysicalMaterial({map:timber.map,bumpMap:timber.bump,bumpScale:.003,color:0xc8a071,roughness:.43,clearcoat:.12,clearcoatRoughness:.6,dithering:true});
 const steel=new T.MeshStandardMaterial({color:0x353b37,metalness:.72,roughness:.39,dithering:true});
 const rope=new T.MeshStandardMaterial({map:canvas.map,color:0xb5ad8b,roughness:.94});
 const seamMat=new T.MeshStandardMaterial({map:canvas.map,color:0xb4a17e,roughness:.92});
 function cloth(fabric='beige',reinforced=false){
  const material=new T.MeshPhysicalMaterial({map:canvas.map,bumpMap:canvas.bump,bumpScale:reinforced?.012:.028,color:reinforced?0x737b60:fabric==='white'?0xe7e4d8:0xbba27c,roughness:.89,sheen:.28,sheenColor:reinforced?0x9a9f83:0xeee3cb,sheenRoughness:.94,side:T.DoubleSide,dithering:true});
  // Broad, low-amplitude tension ripples coexist with the micro weave. Normal
  // perturbation preserves exact shared hems, zipper and LinkFlex intersections.
  material.onBeforeCompile=shader=>{
   shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vClothPosition;').replace('#include <begin_vertex>','#include <begin_vertex>\nvClothPosition=position;');
   shader.fragmentShader=shader.fragmentShader.replace('#include <common>','#include <common>\nvarying vec3 vClothPosition;');
   shader.fragmentShader=shader.fragmentShader.replace('vec3 outgoingLight =',`
#if NUM_DIR_LIGHTS > 0
 if(gl_FrontFacing) totalDiffuse += diffuseColor.rgb * directionalLights[0].color * pow(max(0.0,dot(-normal,directionalLights[0].direction)),1.4) * .13;
#endif
vec3 outgoingLight =`);
   shader.fragmentShader=shader.fragmentShader.replace('#include <normal_fragment_maps>',`#include <normal_fragment_maps>
    vec3 cp=vClothPosition;
    float angle=atan(cp.x,cp.z);
    float ripple=sin(cp.y*38.0+sin(angle*19.0)*1.4)*.0011+sin(angle*83.0+cp.y*2.2)*.0008;
    normal=perturbNormalArb(-vViewPosition,normal,vec2(dFdx(ripple),dFdy(ripple)),faceDirection);
   `);
  };
  material.customProgramCacheKey=()=> 'tentipi-woven-canvas-1';
  return material;
 }
 return {wood,furnitureWood,steel,rope,seamMat,cloth,clothTexture:canvas.map};
}
