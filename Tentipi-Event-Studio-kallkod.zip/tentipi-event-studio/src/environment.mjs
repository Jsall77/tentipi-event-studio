import {HDRLoader} from 'three/addons/loaders/HDRLoader.js';

// Procedural presentation environments. These are visual context, never survey
// data: the tent's central 11 m radius stays level and free of decoration.
const PALETTES={
 studio:{background:'#e8e8df',fog:'#e8e8df',sunColor:'#ffedcf',sunIntensity:3.5,ambientIntensity:.38,exposure:1.05,ground:'#b7b4a5',skyTop:'#e2e5de',skyHorizon:'#eeeae0'},
 summer:{background:'#d5e1d6',fog:'#d5e1d6',sunColor:'#fff0d6',sunIntensity:3.6,ambientIntensity:.32,exposure:1.02,ground:'#89915d',skyTop:'#9cbdd1',skyHorizon:'#e5e8d4'},
 autumn:{background:'#ded3bc',fog:'#ded3bc',sunColor:'#ffe0af',sunIntensity:3.1,ambientIntensity:.28,exposure:1.06,ground:'#9d8862',skyTop:'#bacbd0',skyHorizon:'#e7ddc8'},
 winter:{background:'#dce3e5',fog:'#dce3e5',sunColor:'#e9f3ff',sunIntensity:2.9,ambientIntensity:.42,exposure:.98,ground:'#e2e7e6',skyTop:'#9db7c9',skyHorizon:'#eef0ec'},
 desert:{background:'#e6d4b4',fog:'#e6d4b4',sunColor:'#ffe3b3',sunIntensity:3.9,ambientIntensity:.28,exposure:1.02,ground:'#cdb180',skyTop:'#aebfc3',skyHorizon:'#f0d9b5'}
};
const NIGHT={background:'#172330',fog:'#172330',sunColor:'#9eb7da',sunIntensity:.16,ambientIntensity:.1,exposure:1.16};

export function createEnvironment(T,scene,onStatus){
 let group=null,current=null,generation=0,disposed=false;
 const originalEnvironment=scene.environment,originalIntensity=scene.environmentIntensity;
 const textures=new Map(),pending=new Map(),groundTextures=new Map(),groundPending=new Map(),normalTextures=new Map(),normalPending=new Map();
 const loader=new HDRLoader(),groundLoader=new T.TextureLoader();
 const notify=(name,status)=>{try{onStatus?.({name,status})}catch{}};
 function restoreLighting(){scene.environment=originalEnvironment;scene.environmentIntensity=originalIntensity}
 function photograph(name){
  if(textures.has(name))return Promise.resolve(textures.get(name));
  if(pending.has(name))return pending.get(name);
  // One 1k HDR per season, shared between day and evening and retained until
  // dispose. No private assets, network APIs or third-party rendering service.
  const request=loader.loadAsync('environment-'+name+'.hdr').then(texture=>{
   if(disposed){texture.dispose();throw new Error('Environment disposed')}
   texture.mapping=T.EquirectangularReflectionMapping;
   textures.set(name,texture);return texture;
  }).finally(()=>pending.delete(name));
  pending.set(name,request);return request;
 }
 function groundPhotograph(name){
  if(groundTextures.has(name))return Promise.resolve(groundTextures.get(name));
  if(groundPending.has(name))return groundPending.get(name);
  const request=groundLoader.loadAsync('ground-'+name+'.jpg').then(texture=>{
   if(disposed){texture.dispose();throw new Error('Environment disposed')}
   texture.colorSpace=T.SRGBColorSpace;texture.wrapS=texture.wrapT=T.RepeatWrapping;
   const tileWidth={summer:2,autumn:1.3,winter:2,desert:1.5}[name]||2;
   texture.repeat.set(90/tileWidth,90/tileWidth);texture.anisotropy=8;
   groundTextures.set(name,texture);return texture;
  }).finally(()=>groundPending.delete(name));
  groundPending.set(name,request);return request;
 }
 function groundNormal(name,map){if(normalTextures.has(name))return Promise.resolve(normalTextures.get(name));if(normalPending.has(name))return normalPending.get(name);const request=groundLoader.loadAsync('ground-'+name+'-normal.jpg').then(normal=>{if(disposed){normal.dispose();return null;}normal.wrapS=normal.wrapT=T.RepeatWrapping;normal.repeat.copy(map.repeat);normal.anisotropy=8;normalTextures.set(name,normal);return normal;}).catch(()=>null).finally(()=>normalPending.delete(name));normalPending.set(name,request);return request;}
 function nearGround(name){
  // The high orbit camera must see true tiled ground, not the stretched nadir
  // of the panorama. Vertex alpha blends into the photographic far distance.
  const points=[],uv=[],colors=[],indices=[],rings=[0,8,16,25,30,35,39,42,45],segments=128;
  for(const radius of rings)for(let i=0;i<=segments;i++){
   const angle=i/segments*Math.PI*2,x=Math.sin(angle)*radius,z=Math.cos(angle)*radius;
   points.push(x,-.06,z);uv.push(x/90+.5,z/90+.5);
   const t=Math.max(0,Math.min(1,(radius-25)/17)),alpha=1-t*t*(3-2*t);
   colors.push(1,1,1,alpha);
  }
  for(let ring=0;ring<rings.length-1;ring++)for(let i=0;i<segments;i++){
   const a=ring*(segments+1)+i,b=a+segments+1;indices.push(a,b,a+1,a+1,b,b+1);
  }
  const g=geometry(new T.BufferGeometry());g.setAttribute('position',new T.Float32BufferAttribute(points,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setAttribute('color',new T.Float32BufferAttribute(colors,4));g.setIndex(indices);g.computeVertexNormals();
  const m=material(new T.MeshStandardMaterial({color:PALETTES[name].ground,roughness:1,vertexColors:true,transparent:true,depthWrite:true}));
  const ground=new T.Mesh(g,m);ground.name='Photographic near ground';ground.receiveShadow=true;ground.renderOrder=1;return ground;
 }
 function showPhotograph(texture,name,night,ticket,groundRequest){
  // An ordinary panorama preserves distant scenery without radial ground
  // stretching; the nearby ground has separately scaled photographic textures.
  const photoGroup=new T.Group();photoGroup.name='Photographic environment';
  const sky=new T.Mesh(new T.SphereGeometry(105,64,32),new T.MeshBasicMaterial({map:texture,side:T.BackSide,depthWrite:false,fog:false}));
  sky.material.color.setScalar(night?.12:1);sky.renderOrder=-100;
  geometries.add(sky.geometry);materials.add(sky.material);photoGroup.add(sky);
  const ground=nearGround(name);photoGroup.add(ground);
  groundRequest.then(map=>{if(!map||disposed||generation!==ticket||current!==name+':'+night)return;ground.material.map=map;ground.material.color.set('#ffffff');ground.material.needsUpdate=true;groundNormal(name,map).then(normal=>{if(!normal||generation!==ticket)return;ground.material.normalMap=normal;ground.material.normalScale=new T.Vector2(.35,.35);ground.material.needsUpdate=true;notify(name,'normal-ready');});});
  for(const child of group.children)child.visible=false;
  group.add(photoGroup);scene.environment=texture;scene.environmentIntensity=night?.065:originalIntensity;
 }

 const geometries=new Set(),materials=new Set();
 const geometry=g=>(geometries.add(g),g),material=m=>(materials.add(m),m);
 const mat=(color,roughness=1)=>material(new T.MeshStandardMaterial({color,roughness}));
 const smooth=t=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t)};
 function random(seed){let n=seed;return()=>{n=(n*16807)%2147483647;return(n-1)/2147483646}}
 function clear(){restoreLighting();if(group){scene.remove(group);group=null}for(const g of geometries)g.dispose();for(const m of materials)m.dispose();geometries.clear();materials.clear()}
 function addInstances(g,m,transforms,colors){
  if(!transforms.length)return null;
  const mesh=new T.InstancedMesh(g,m,transforms.length);const dummy=new T.Object3D();
  transforms.forEach((v,i)=>{dummy.position.set(...v.position);dummy.rotation.set(...(v.rotation||[0,0,0]));dummy.scale.set(...(v.scale||[1,1,1]));dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);if(colors)mesh.setColorAt(i,new T.Color(colors[i%colors.length]));});
  mesh.instanceMatrix.needsUpdate=true;if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;
  mesh.receiveShadow=true;group.add(mesh);return mesh;
 }
 function segment(a,b,r){
  const start=new T.Vector3(...a),end=new T.Vector3(...b),delta=end.clone().sub(start),q=new T.Quaternion().setFromUnitVectors(new T.Vector3(0,1,0),delta.clone().normalize());
  const e=new T.Euler().setFromQuaternion(q);
  return{position:start.add(end).multiplyScalar(.5).toArray(),rotation:[e.x,e.y,e.z],scale:[r,delta.length(),r]};
 }
 function terrainHeight(x,z,name){
  const r=Math.hypot(x,z),rise=smooth((r-12)/15);
  if(name==='studio')return-.075;
  if(name==='desert')return-.075+rise*(.42+1.3*Math.sin(x*.095+z*.033)+.85*Math.cos(z*.115-x*.04));
  return-.075+rise*(.48*Math.sin(x*.09)*Math.cos(z*.08)+.24*Math.sin((x+z)*.13));
 }
 function makeTerrain(name,p){
  const rings=[0,11,14,19,26,36,50,68,90],segments=128,points=[],indices=[];
  for(const radius of rings)for(let i=0;i<=segments;i++){
   const a=i/segments*Math.PI*2,x=Math.sin(a)*radius,z=Math.cos(a)*radius;
   points.push(x,terrainHeight(x,z,name),z);
  }
  for(let ring=0;ring<rings.length-1;ring++)for(let i=0;i<segments;i++){
   const a=ring*(segments+1)+i,b=a+segments+1;
   indices.push(a,b,a+1,a+1,b,b+1);
  }
  const g=geometry(new T.BufferGeometry());g.setAttribute('position',new T.Float32BufferAttribute(points,3));g.setIndex(indices);g.computeVertexNormals();
  const mesh=new T.Mesh(g,mat(p.ground));mesh.receiveShadow=true;group.add(mesh);
 }
 function makeSky(p,night){
  const m=material(new T.ShaderMaterial({side:T.BackSide,depthWrite:false,uniforms:{top:{value:new T.Color(night?'#0b1525':p.skyTop)},horizon:{value:new T.Color(night?'#283746':p.skyHorizon)},night:{value:night?1:0}},vertexShader:'varying vec3 direction; void main(){direction=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',fragmentShader:'varying vec3 direction; uniform vec3 top; uniform vec3 horizon; uniform float night; void main(){vec3 d=normalize(direction);float h=smoothstep(-0.06,0.75,d.y);vec3 color=mix(horizon,top,h);float glow=pow(max(0.0,dot(d,normalize(vec3(-0.45,0.48,0.65)))),40.0);color+=vec3(0.09,0.065,0.025)*glow*(1.0-night);gl_FragColor=vec4(color,1.0);\n#include <tonemapping_fragment>\n#include <colorspace_fragment>\n}'}));
  const sky=new T.Mesh(geometry(new T.SphereGeometry(105,32,16)),m);sky.renderOrder=-100;group.add(sky);
 }
 function woodland(name){
  const rnd=random(7521),trunks=[],branches=[],crowns=[],snow=[],leaves=[],grass=[];
  const winter=name==='winter',autumn=name==='autumn';
  const colors=autumn?['#9b672f','#b17d36','#806d3a','#99623d','#b49348']:['#58704a','#6e8051','#718553','#4e6a46','#7d8c59'];
  // Offset arcs avoid a repetitive fence of equal silhouettes. Trunks fork into
  // real branch segments, with overlapping irregular broadleaf crowns.
  for(let i=0;i<56;i++){
   const a=i/56*Math.PI*2+(rnd()-.5)*.12,r=25+rnd()*35,x=Math.sin(a)*r,z=Math.cos(a)*r,y=terrainHeight(x,z,name),h=4.2+rnd()*5.5;
   const leanX=(rnd()-.5)*.65,leanZ=(rnd()-.5)*.65,top=[x+leanX,y+h,z+leanZ];
   trunks.push(segment([x,y,z],[x+leanX*.45,y+h*.69,z+leanZ*.45],.13+rnd()*.12));
   for(let j=0;j<5;j++){
    const b=j/5*Math.PI*2+rnd()*.5,spread=1.05+rnd()*1.35,from=[x+leanX*.35,y+h*(.45+j*.035),z+leanZ*.35],tip=[top[0]+Math.sin(b)*spread,y+h*(.72+rnd()*.25),top[2]+Math.cos(b)*spread];
    branches.push(segment(from,tip,.035+rnd()*.035));
    if(winter){
     const fork=[tip[0]+Math.sin(b+.6)*.65,tip[1]+.6+rnd()*.5,tip[2]+Math.cos(b+.6)*.65];branches.push(segment(tip,fork,.022));
    }else crowns.push({position:[tip[0],tip[1]-.12,tip[2]],rotation:[rnd(),rnd()*Math.PI,rnd()],scale:[1.3+rnd()*.65,1.2+rnd()*.9,1.25+rnd()*.7]});
   }
   if(winter)snow.push({position:[x,y+.02,z],scale:[.7+rnd(),.08+rnd()*.1,.7+rnd()]});
  }
  addInstances(geometry(new T.CylinderGeometry(.7,1,1,7)),mat(winter?'#706e65':'#77694e'),trunks);
  addInstances(geometry(new T.CylinderGeometry(.35,1,1,6)),mat(winter?'#78796f':'#786b51'),branches);
  if(!winter)addInstances(geometry(new T.SphereGeometry(1,9,7)),mat('#ffffff'),crowns,colors);
  if(winter)addInstances(geometry(new T.SphereGeometry(1,10,6)),mat('#eef0ed'),snow);
  // Sparse near-ground accents begin outside the clear central radius.
  if(!winter){
   for(let i=0;i<280;i++){
    const a=rnd()*Math.PI*2,r=12.5+rnd()*20,x=Math.sin(a)*r,z=Math.cos(a)*r,y=terrainHeight(x,z,name);
    if(autumn)leaves.push({position:[x,y+.015,z],rotation:[-.10+rnd()*.2,rnd()*Math.PI,0],scale:[.08+rnd()*.1,.008,.045+rnd()*.07]});
    else grass.push({position:[x,y+.09,z],rotation:[0,rnd()*Math.PI,0],scale:[.16+rnd()*.16,.1+rnd()*.18,.12+rnd()*.12]});
   }
   if(autumn)addInstances(geometry(new T.SphereGeometry(1,5,3)),mat('#ffffff'),leaves,['#b48843','#8f6539','#b99b55']);
   else addInstances(geometry(new T.SphereGeometry(1,5,3)),mat('#6f7e4b'),grass);
  }
 }
 function desert(){
  const rnd=random(3124),rocks=[];
  for(let i=0;i<35;i++){
   const a=rnd()*Math.PI*2,r=17+rnd()*45,x=Math.sin(a)*r,z=Math.cos(a)*r,y=terrainHeight(x,z,'desert'),s=.12+rnd()*.42;
   rocks.push({position:[x,y+s*.2,z],rotation:[rnd()*.3,rnd()*Math.PI,rnd()*.2],scale:[s*1.7,s*.5,s]});
  }
  addInstances(geometry(new T.DodecahedronGeometry(1,0)),mat('#ffffff'),rocks,['#b49d79','#b7a582','#a99271']);
 }
 function set(name,night=false){
  name=Object.hasOwn(PALETTES,name)?name:'studio';night=Boolean(night);
  const p=PALETTES[name],key=name+':'+night;
  if(!disposed&&current!==key){
   const ticket=++generation;
   clear();group=new T.Group();group.name='Tentipi presentation environment: '+name;scene.add(group);makeTerrain(name,p);makeSky(p,night);if(['summer','autumn','winter'].includes(name))woodland(name);if(name==='desert')desert();current=key;
   if(name!=='studio'){
    notify(name,'loading');
    const groundRequest=groundPhotograph(name).catch(()=>null);
    photograph(name).then(texture=>{
     if(disposed||generation!==ticket||current!==key)return;
     showPhotograph(texture,name,night,ticket,groundRequest);notify(name,'ready');
    }).catch(()=>{if(!disposed&&generation===ticket&&current===key)notify(name,'fallback')});
   }
  }
  const {background,fog,sunColor,sunIntensity,ambientIntensity,exposure}=night?NIGHT:p;
  return{background,fog,sunColor,sunIntensity,ambientIntensity,exposure};
 }
 return{set,dispose(){disposed=true;generation++;clear();for(const texture of textures.values())texture.dispose();for(const texture of groundTextures.values())texture.dispose();for(const texture of normalTextures.values())texture.dispose();normalTextures.clear();textures.clear();groundTextures.clear();current=null}};
}
