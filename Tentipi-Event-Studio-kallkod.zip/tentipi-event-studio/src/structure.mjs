import {bayAngle} from './model.mjs';
import {canopyLift} from './canopy.mjs';
const polar=(r,y,a)=>[Math.sin(a)*r,y,Math.cos(a)*r];
export const MAIN={footRadius:5.05,footHeight:.08,topRadius:.12,topHeight:6.65};

// Arrangement interpreted from Tentipi's main/secondary and lifting-console
// detail photographs. These coordinates are visual, not assembly dimensions.
export function frameAtBoundary(walls,i){
 const a=bayAngle(i)-Math.PI/9,c=MAIN;
 const main=[polar(c.footRadius,c.footHeight,a),polar(c.topRadius,c.topHeight,a)];
 if(canopyLift(walls,i,0)!==1)return {main,beam:null,strut:null,secondary:[]};
 const beamStart=polar(3.25,2.60,a),beamEnd=polar(6.5,2.27,a),r=4.45;
 const mainY=c.footHeight+(c.footRadius-r)/(c.footRadius-c.topRadius)*(c.topHeight-c.footHeight);
 const beamY=2.60+(r-3.25)/(6.5-3.25)*(2.27-2.60);
 return {main,beam:[beamStart,beamEnd],strut:[polar(r,mainY,a),polar(r,beamY,a)]};
}
