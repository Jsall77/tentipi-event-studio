import {bayAngle} from './model.mjs';
import {canopyLift} from './canopy.mjs';
const polar=(r,y,a)=>[Math.sin(a)*r,y,Math.cos(a)*r];
export const MAIN={footRadius:5.05,footHeight:.08,topRadius:.12,topHeight:6.65};

// Main frame interpreted from manufacturer photos; loose vertical lifting
// supports follow the owner's assembly clarification. Visual coordinates only.
export function frameAtBoundary(walls,i){
 const a=bayAngle(i)-Math.PI/9,c=MAIN;
 const main=[polar(c.footRadius,c.footHeight,a),polar(c.topRadius,c.topHeight,a)];
 if(canopyLift(walls,i,0)!==1)return {main,beam:null,support:null};
 const beamStart=polar(3.25,2.60,a),beamEnd=polar(6.5,2.27,a);
 // Loose lifting poles stand vertically on the ground. Guy ropes are rendered
 // separately and must never be substituted for this wooden support.
 return {main,beam:[beamStart,beamEnd],support:[polar(6.5,.03,a),beamEnd]};
}
