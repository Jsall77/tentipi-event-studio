import {localPoint} from './layout.mjs';
import {bayAngle} from './model.mjs';
import {canopyHeightAtRadius,canopyPoint} from './canopy.mjs';

// Rendering clearance only, not a specified product overlap dimension.
export const UNDERLAY_CLEARANCE=.08;
export function roofHeightAtTent(t,x,z){
 const p=localPoint({x,z},t),ang=Math.atan2(p.x,p.z),r=Math.hypot(p.x,p.z);let i=0,d=Infinity,delta=0;
 for(let k=0;k<9;k++){const e=Math.atan2(Math.sin(ang-bayAngle(k)),Math.cos(ang-bayAngle(k)));if(Math.abs(e)<d){i=k;d=Math.abs(e);delta=e;}}
 const u=Math.max(0,Math.min(1,.5+delta/(Math.PI*2/9))),edge=canopyPoint(t.config.walls,i,u,1);
 return r<=Math.hypot(edge[0],edge[2])-1e-5?canopyHeightAtRadius(t.config.walls,i,u,r):null;
}
export function coveringRoofHeight(tents,x,z){const values=tents.map(t=>roofHeightAtTent(t,x,z)).filter(y=>y!==null);return values.length?Math.min(...values):null;}
export function underlayHeight(tents,x,z){const roof=coveringRoofHeight(tents,x,z);return roof===null?null:roof-UNDERLAY_CLEARANCE;}
export function coveredTriangles(tents,points,indices){
 const kept=[];for(let i=0;i<indices.length;i+=3){const tri=indices.slice(i,i+3),[a,b,c]=tri.map(n=>points[n]);
 // Do not leave an exterior connector flap beyond the tent's own fabric.
 const samples=[a,b,c,...[[a,b],[b,c],[c,a]].map(([p,q])=>p.map((v,k)=>(v+q[k])/2)),a.map((v,k)=>(v+b[k]+c[k])/3)];
 if(samples.every(p=>{const roof=coveringRoofHeight(tents,p[0],p[2]);return roof!==null&&p[1]<roof-.025;}))kept.push(...tri);
 }return kept;
}
