// Centimetre-scale slack in the fabric, zero at every shared seam, hem and neck.
// A visual normal-direction relief only; no change to the canopy outline or
// catalogue dimensions. Smaller than the LinkFlex rendering clearance.
export function clothRelief(u,v,section=0){
 const envelope=Math.sin(Math.PI*u)**2*Math.sin(Math.PI*v)**2;
 const fold=Math.sin(v*98+Math.sin(u*21+section)*1.3)*.6+Math.sin(v*51-u*13+section*.7)*.4;
 return .018*envelope*fold;
}
