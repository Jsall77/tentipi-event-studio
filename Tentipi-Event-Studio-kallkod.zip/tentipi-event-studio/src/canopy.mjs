import {bayAngle} from './model.mjs';

export const CANOPY={bays:9,halfAngle:Math.PI/9,peak:6.8,bodyTop:6.35,kneeRadius:3.25,topRadius:.48,closedRadius:5.15,raisedRadius:6.5,closedHem:.06,raisedHem:2.3};
const mix=(a,b,t)=>a+(b-a)*t;
const raised=(walls,i)=>walls[(i+9)%9]!=='down'?1:0;
const smooth=t=>t*t*(3-2*t);

// A lifted corner belongs to both neighbouring fabric panels. A lowered panel
// drapes to its own low centre, keeping WallFlex's raised corners at full height.
export function canopyLift(walls,i,u){
 const own=raised(walls,i),left=Math.max(own,raised(walls,i-1)),right=Math.max(own,raised(walls,i+1));
 return u<=.5?mix(left,own,smooth(u*2)):mix(own,right,smooth((u-.5)*2));
}
export function canopyProfile(lift,v){
 const c=CANOPY,R=mix(c.closedRadius,c.raisedRadius,lift),hem=mix(c.closedHem,c.raisedHem,lift);
 const closedKnee=mix(c.bodyTop,c.closedHem,(c.kneeRadius-c.topRadius)/(c.closedRadius-c.topRadius));
 const knee=mix(closedKnee,2.65,lift);
 if(v<=.64){const t=v/.64;return {r:mix(c.topRadius,c.kneeRadius,t),y:mix(c.bodyTop,knee,t)}}
 const t=(v-.64)/.36;return {r:mix(c.kneeRadius,R,t),y:mix(knee,hem,t)};
}
function chordFactor(u){return Math.cos(CANOPY.halfAngle)/Math.cos((u-.5)*CANOPY.halfAngle*2)}
export function canopyPoint(walls,i,u,v){
 const a=bayAngle(i)+(u-.5)*CANOPY.halfAngle*2,{r,y}=canopyProfile(canopyLift(walls,i,u),v),radius=r*chordFactor(u);
 return [Math.sin(a)*radius,y-.10*Math.sin(Math.PI*u)*Math.sin(Math.PI*v),Math.cos(a)*radius];
}
export function canopyHeightAtRadius(walls,i,u,radius){
 const lift=canopyLift(walls,i,u),r=radius/chordFactor(u),R=mix(CANOPY.closedRadius,CANOPY.raisedRadius,lift);
 const v=r<=CANOPY.kneeRadius?.64*(r-CANOPY.topRadius)/(CANOPY.kneeRadius-CANOPY.topRadius):.64+.36*(r-CANOPY.kneeRadius)/(R-CANOPY.kneeRadius);
 return canopyPoint(walls,i,u,Math.max(0,Math.min(1,v)))[1];
}
export function planHalfExtents(aspect){
 const half=8.8,ratio=Math.max(.01,aspect);
 return {x:half*Math.max(1,ratio),y:half*Math.max(1,1/ratio)};
}

export function ventPoint(open,u,v){
 const a=u*Math.PI*2,hem=6.27+(open?.31+.045*Math.cos(a):0),r=.66*v*(1+.025*Math.sin(a*9)*v*v);
 return [Math.sin(a)*r,CANOPY.peak+(hem-CANOPY.peak)*v,Math.cos(a)*r];
}
