import {bayAngle} from './model.mjs';

export const CANOPY={bays:9,halfAngle:Math.PI/9,peak:6.8,bodyTop:6.35,kneeRadius:3.25,topRadius:.48,closedRadius:5.15,raisedRadius:6.5,closedHem:.06,raisedHem:2.3};
const mix=(a,b,t)=>a+(b-a)*t;
const raised=(walls,i)=>walls[(i+9)%9]!=='down'?1:0;
const smooth=t=>t*t*(3-2*t);

// A lifted corner belongs to both neighbouring fabric panels. A lowered panel
// drapes to its own low centre, keeping WallFlex's raised corners at full height.
export function canopyLift(walls,i,u){
 const own=raised(walls,i),left=Math.max(own,raised(walls,i-1)),right=Math.max(own,raised(walls,i+1));
 return u<=.5?mix(left,own,smooth(u*2)):mix(own,right,smooth((u-.5)*2));
}
export function canopyProfile(lift,v){
 const c=CANOPY,R=mix(c.closedRadius,c.raisedRadius,lift),hem=mix(c.closedHem,c.raisedHem,lift);
 const closedKnee=mix(c.bodyTop,c.closedHem,(c.kneeRadius-c.topRadius)/(c.closedRadius-c.topRadius));
 const knee=mix(closedKnee,2.65,lift);
 if(v<=.64){const t=v/.64;return {r:mix(c.topRadius,c.kneeRadius,t),y:mix(c.bodyTop,knee,t)}}
 const t=(v-.64)/.36;return {r:mix(c.kneeRadius,R,t),y:mix(knee,hem,t)};
}
function chordFactor(u){return Math.cos(CANOPY.halfAngle)/Math.cos((u-.5)*CANOPY.halfAngle*2)}
export function canopyPoint(walls,i,u,v){
 const a=bayAngle(i)+(u-.5)*CANOPY.halfAngle*2,{r,y}=canopyProfile(canopyLift(walls,i,u),v),radius=r*chordFactor(u);
 return [Math.sin(a)*radius,y-.10*Math.sin(Math.PI*u)*Math.sin(Math.PI*v),Math.cos(a)*radius];
}
export function canopyHeightAtRadius(walls,i,u,radius){
 const lift=canopyLift(walls,i,u),r=radius/chordFactor(u),R=mix(CANOPY.closedRadius,CANOPY.raisedRadius,lift);
 const v=r<=CANOPY.kneeRadius?.64*(r-CANOPY.topRadius)/(CANOPY.kneeRadius-CANOPY.topRadius):.64+.36*(r-CANOPY.kneeRadius)/(R-CANOPY.kneeRadius);
 return canopyPoint(walls,i,u,Math.max(0,Math.min(1,v)))[1];
}
export function planHalfExtents(aspect){
 const half=8.8,ratio=Math.max(.01,aspect);
 return {x:half*Math.max(1,ratio),y:half*Math.max(1,1/ratio)};
}

// The top is fixed. Pulling the hem up gathers the fabric into soft pleats.
// A continuous 0..1 opening parameter is used by the animation as well as tests.
export function ventPoint(open,u,v){
 const t=Math.max(0,Math.min(1,Number(open))),a=u*Math.PI*2;
 const drop=.53*(.38*v+.62*v*v*v);
 const folds=(Math.sin(a*9+.35)*Math.sin(Math.PI*v)*.035+Math.sin(a*3+.7)*v*v*.012)*(1-.7*t);
 const gathered=.08*t*Math.sin(v*Math.PI*6)*v*(1-v);
 const r=.66*v*(1+.045*Math.sin(a*9)*v*v+.02*Math.sin(a*3)*v)-.105*t*v*v+.055*t*Math.sin(a*9)*Math.sin(Math.PI*v)+.045*t*Math.sin(v*Math.PI*4)*Math.sin(Math.PI*v);
 return [Math.sin(a)*r,CANOPY.peak-Math.max(.015*v,drop*(1-.72*t)-folds-gathered),Math.cos(a)*r];
}

// A down bay beside WallFlex needs a curved fabric gusset below its lifted hem.
// A flat triangle at the shared boundary alone leaves a crescent-shaped hole.
export function transitionInfills(walls,i){
 if(walls[i]!=='down')return [];
 const enclosed=mode=>mode==='window'||mode==='canvas',ranges=[];
 if(enclosed(walls[(i+8)%9]))ranges.push([0,.5]);
 if(enclosed(walls[(i+1)%9]))ranges.push([.5,1]);
 return ranges.map(([lo,hi])=>{const points=[],indices=[],closed=Array(9).fill('down'),steps=24;for(let k=0;k<=steps;k++){const u=lo+(hi-lo)*k/steps,top=canopyPoint(walls,i,u,1),bottom=canopyPoint(closed,i,u,1);bottom[1]=.04;points.push(...bottom,...top);if(k<steps){const n=k*2;indices.push(n,n+1,n+2,n+1,n+3,n+2);}}return {points,indices,lo,hi};});
}
