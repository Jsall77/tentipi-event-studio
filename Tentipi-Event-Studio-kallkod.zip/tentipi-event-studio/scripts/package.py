from pathlib import Path
import hashlib,json,re,zipfile
root=Path(__file__).resolve().parents[1]
files=[]
for folder in ['src','scripts','integration','tests']:
    files.extend(p for p in (root/folder).rglob('*') if p.is_file())
for folder in ['research','qa']:
    files.extend(p for p in (root/folder).glob('*') if p.is_file() and p.suffix in ['.txt','.json'] and p.name!='source-package-manifest.json')
files.extend(p for p in (root/'dist/assets').glob('*') if p.is_file())
files.extend(root/f for f in ['README.md','package.json','.gitignore'])
files=sorted(set(files))
for p in files:
    assert not p.is_symlink()
    assert not any(s in p.relative_to(root).parts for s in ['node_modules','.openai','.git'])
    assert not p.name.startswith('.env')
    assert not re.search(rb'-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----|ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}',p.read_bytes())
archive=root/'dist/Tentipi-Event-Studio-kallkod.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:z.write(p,'tentipi-event-studio/'+str(p.relative_to(root)))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
manifest={'date':'2026-11-02','archive':archive.name,'file_count':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':[{'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
(root/'qa/source-package-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(root/'dist/README.md').write_text((root/'README.md').read_text()+'\nDownload developer source: [Tentipi-Event-Studio-kallkod.zip](Tentipi-Event-Studio-kallkod.zip)\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2))
