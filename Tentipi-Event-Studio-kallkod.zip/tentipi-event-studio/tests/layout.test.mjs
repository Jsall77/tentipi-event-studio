import test from 'node:test';
import assert from 'node:assert/strict';
import {defaultState,editedState,normalize,encode,decode,bill,textSummary} from '../src/model.mjs';
import {MAX_TENTS,LAYOUT_LIMIT,LINK_SPACING,tentEntries,activeTent,selectTent,addTent,removeTent,moveTent,connectTents,disconnect,presetLayout,connectedIds,connectionBays,posePoint,localPoint,roofPairs,siteBounds} from '../src/layout.mjs';

const edit=(s,fn)=>editedState(s,fn);
const tent=(s,id)=>tentEntries(s).find(t=>t.id===id);
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-9,`${a} ≠ ${b}`);
const kitCount=s=>bill(s).find(r=>r.name.includes('Linking kit'))?.qty??0;
const pair=()=>edit(defaultState(),d=>presetLayout(d,'pair'));
const independent=()=>edit(defaultState(),d=>{addTent(d,{linked:false});addTent(d,{linked:false});});
const withoutOpenings=(config,bays)=>({...config,walls:config.walls.map((v,i)=>bays.has(i)?'open':v),doors:config.doors.map((v,i)=>bays.has(i)?false:v)});

test('legacy single-tent projects keep their data when a site is introduced',()=>{
 const original=normalize(defaultState());
 const s=edit(original,d=>addTent(d,{linked:false}));
 assert.equal(s.site.tents.length,2);
 assert.deepEqual(tent(s,'t1').config,original);
 assert.deepEqual(original,normalize(original));
 assert.equal('site' in original,false);
 assert.deepEqual(decode(encode(original)),original);
});

test('switching tents retains each tent’s fabric, walls, doors and furniture',()=>{
 let s=edit(defaultState(),d=>{d.fabric='white';d.walls=Array(9).fill('canvas');d.doors[4]=true;d.floor=false;d.lights=false;d.ventOpen=false;d.entranceOpen=false;d.items=d.items.slice(0,1);d.items[0].x=2.125;addTent(d,{linked:false});});
 const first=structuredClone(tent(s,'t1').config),secondId=s.site.activeId;
 s=edit(s,d=>{d.fabric='beige';d.walls[4]='window';d.doors[4]=false;d.floor=true;d.lights=true;d.ventOpen=true;d.entranceOpen=true;d.items[0].x=-2.25;});
 const second=structuredClone(activeTent(s).config);
 s=edit(s,d=>selectTent(d,'t1'));
 assert.deepEqual(activeTent(s).config,first);
 s=edit(s,d=>selectTent(d,secondId));
 assert.deepEqual(activeTent(s).config,second);
 assert.deepEqual(tent(s,'t1').config,first);
});

test('connected bays automatically open three adjacent sections and clear doors',()=>{
 let s=edit(defaultState(),d=>{d.walls=Array(9).fill('canvas');d.doors=Array(9).fill(true);addTent(d,{bay:0});});
 const expected=new Set([8,0,1]);
 for(const t of tentEntries(s)){
  assert.deepEqual(connectionBays(s,t.id),expected);
  for(let i=0;i<9;i++){assert.equal(t.config.walls[i],expected.has(i)?'open':'canvas');assert.equal(t.config.doors[i],!expected.has(i));}
 }
 s=edit(s,d=>{d.walls[0]='window';d.doors[0]=true;});
 assert.equal(s.walls[0],'open');assert.equal(s.doors[0],false);
});

test('the third triangle roof seam opens its bays while retaining two linking kits',()=>{
 const base=defaultState();base.walls=Array(9).fill('canvas');base.doors=Array(9).fill(true);
 const s=edit(base,d=>presetLayout(d,'triangle'));
 // The minimum spanning tree stores t1→t2 and t1→t3; the roofs also meet at t2→t3.
 for(const [id,bays]of[['t2',[5,6,7]],['t3',[7,8,0]]])for(const bay of bays){
  assert.equal(tent(s,id).config.walls[bay],'open',id+' bay '+bay);
  assert.equal(tent(s,id).config.doors[bay],false);
 }
 assert.equal(roofPairs(s).length,3);assert.equal(kitCount(s),2);
});

test('adding and removing linked tents retains existing configurations and no dangling links',()=>{
 const original=normalize(defaultState());
 let s=edit(original,d=>addTent(d,{bay:4}));
 const added=s.site.activeId,first=tent(s,'t1'),second=tent(s,added);
 close(Math.hypot(first.x-second.x,first.z-second.z),LINK_SPACING);
 assert.deepEqual(first.config,withoutOpenings(original,connectionBays(s,'t1')));
 assert.equal(s.site.links.length,1);assert.equal(kitCount(s),1);
 s=edit(s,d=>removeTent(d,added));
 assert.equal(s.site.activeId,'t1');assert.equal(s.site.tents.length,1);
 assert.equal(s.site.links.length,0);assert.equal(kitCount(s),0);
 assert.deepEqual(s.items,original.items);
 assert.throws(()=>edit(s,d=>removeTent(d,'t1')));
});

test('connecting independent tents moves the whole target cluster and disconnecting separates it',()=>{
 let s=independent();const [a,b,c]=s.site.tents.map(t=>t.id);
 s=edit(s,d=>connectTents(d,b,c,2));
 const before=structuredClone(tent(s,c)),oldDistance=Math.hypot(tent(s,b).x-before.x,tent(s,b).z-before.z);
 s=edit(s,d=>connectTents(d,a,b,4));
 assert.equal(connectedIds(s.site,a).size,3);
 close(Math.hypot(tent(s,b).x-tent(s,c).x,tent(s,b).z-tent(s,c).z),oldDistance);
 assert.notDeepEqual({x:tent(s,c).x,z:tent(s,c).z},{x:before.x,z:before.z});
 assert.throws(()=>edit(s,d=>connectTents(d,a,c,0)),/grupp/);
 s=edit(s,d=>disconnect(d,1));
 assert.deepEqual([...connectedIds(s.site,a)],[a]);
 assert.equal(connectedIds(s.site,b).size,2);assert.equal(kitCount(s),1);
});

test('moving a connected cluster rotates around the selected anchor and leaves furniture local',()=>{
 let s=edit(pair(),d=>addTent(d,{linked:false}));
 const [a,b,free]=s.site.tents.map(t=>t.id),before=structuredClone(s),anchor=tent(s,a),target={x:anchor.x+3,z:anchor.z-2,rotation:anchor.rotation+90};
 s=edit(s,d=>moveTent(d,a,target.x,target.z,target.rotation));
 for(const id of[a,b]){
  const old=tent(before,id),next=tent(s,id),expected=posePoint({x:old.x-anchor.x,z:old.z-anchor.z},{...target,rotation:90});
  close(next.x,expected.x);close(next.z,expected.z);close(next.rotation,(old.rotation+90)%360);
  assert.deepEqual(next.config,old.config);
 }
 assert.deepEqual(tent(s,free),tent(before,free));
 const t=tent(s,b),p={x:1.2,z:-3.4};const local=localPoint(posePoint(p,t),t);close(local.x,p.x);close(local.z,p.z);
});

test('failed component moves are atomic at the layout boundary',()=>{
 const s=pair(),before=structuredClone(s),id=s.site.tents[0].id;
 assert.throws(()=>edit(s,d=>moveTent(d,id,LAYOUT_LIMIT+1,0)));
 assert.throws(()=>edit(s,d=>moveTent(d,id,NaN,0)));
 assert.deepEqual(s,before);
});

test('kit counts equal tents minus connected components, including triangle roof coverage',()=>{
 for(const [name,count,kits]of[['pair',2,1],['triangle',3,2],['arc',3,2],['four',4,3],['six',6,5]]){
  const s=edit(defaultState(),d=>presetLayout(d,name));
  assert.equal(s.site.tents.length,count);assert.equal(kitCount(s),kits,name);
 }
 let s=independent();assert.equal(kitCount(s),0);
 s=edit(s,d=>connectTents(d,d.site.tents[0].id,d.site.tents[1].id,0));assert.equal(kitCount(s),1);
 const triangle=edit(defaultState(),d=>presetLayout(d,'triangle'));
 assert.equal(roofPairs(triangle).length,3);assert.equal(kitCount(triangle),2);
});

test('closing a link adds a quotation item without inventing panel dimensions or price',()=>{
 let s=pair();s=edit(s,d=>d.site.links[0].closure='window');
 const rows=bill(s),mid=rows.find(r=>r.name.includes('Midfill'));
 assert.equal(mid.qty,1);assert.equal(mid.sku,null);assert.match(mid.note,/bekräftas/);
 assert.ok(rows.every(r=>!('price' in r)&&!('total' in r)&&!('width' in r)&&!('height' in r)));
 const kit=rows.find(r=>r.name.includes('Linking kit'));assert.equal(kit.sku,null);assert.match(kit.note,/verifieras/);
 const text=textSummary(s);
 assert.match(text,/Centrumavstånd och kopplingsgeometri är illustrativa/);
 assert.match(text,/Slutlig komponentlista, pris/);
 assert.doesNotMatch(text,/\b0 (?:kr|SEK)\b/);
});

test('layout and share exports preserve all tents, active selection, closure and transforms',()=>{
 let s=edit(defaultState(),d=>presetLayout(d,'triangle'));
 s=edit(s,d=>{selectTent(d,'t2');d.fabric='white';d.floor=false;d.items[0].x=2.75;d.site.links[1].closure='canvas';moveTent(d,'t2',7,-1,200);});
 assert.deepEqual(normalize(JSON.parse(JSON.stringify(s))),s);
 assert.deepEqual(decode(encode(s)),s);
 const text=textSummary(s,'https://example.com/#config=all-tents');
 for(const t of tentEntries(s)){assert.ok(text.includes('=== '+t.name+' ==='));assert.ok(text.includes('Centrum X '+t.x.toFixed(2)+' m'));}
 assert.match(text,/Öppna hela layouten: https:\/\/example.com\/#config=all-tents/);
 assert.equal(s.site.activeId,'t2');assert.equal(tent(s,'t2').config.fabric,'white');assert.equal(tent(s,'t1').config.fabric,'beige');
});

test('maximum legal layout and furniture data still produces a readable sharing link',()=>{
 const base=defaultState();base.items=Array.from({length:90},(_,i)=>({id:('i'+i).padEnd(32,'x'),type:'table200',x:-1.0000000000000001e-14,z:-1.0000000000000001e-14,rotation:359.12345678912345}));
 const s=edit(base,d=>presetLayout(d,'six'));
 assert.equal(s.site.tents.length,MAX_TENTS);assert.deepEqual(decode(encode(s)),s);
});

test('hostile or malformed layout imports fail before rendering',()=>{
 const s=pair(),mutations=[
  d=>d.site=null,d=>d.site.tents=[],d=>d.site.tents.push(structuredClone(d.site.tents[0])),d=>d.site.activeId='missing',
  d=>d.site.tents[0].id='<script>',d=>d.site.tents[0].name='x'.repeat(41),d=>d.site.tents[0].x=NaN,d=>d.site.tents[0].z=LAYOUT_LIMIT+.1,d=>d.site.tents[0].rotation=3601,
  d=>d.site.tents[0].config.fabric='constructor',d=>d.site.tents[1].config.site={},
  d=>d.site.links[0].a='missing',d=>d.site.links[0].b=d.site.links[0].a,d=>d.site.links[0].aBay=-1,d=>d.site.links[0].bBay=9,d=>d.site.links[0].aBay=1.5,d=>d.site.links[0].closure='constructor',
  d=>d.site.links.push({...d.site.links[0],a:d.site.links[0].b,b:d.site.links[0].a}),
 ];
 for(const change of mutations){const bad=structuredClone(s);change(bad);assert.throws(()=>normalize(bad));}
 const triangle=edit(defaultState(),d=>presetLayout(d,'triangle'));
 triangle.site.links.push({a:'t2',b:'t3',aBay:0,bBay:0,closure:'open'});
 assert.throws(()=>normalize(triangle),/slinga/);
});

test('bounds include every tent and the tent limit rejects additions atomically',()=>{
 const s=edit(defaultState(),d=>presetLayout(d,'six')),before=structuredClone(s),bounds=siteBounds(s);
 for(const t of tentEntries(s)){assert.ok(t.x>bounds.minX&&t.x<bounds.maxX);assert.ok(t.z>bounds.minZ&&t.z<bounds.maxZ);}
 assert.equal(bounds.width,bounds.maxX-bounds.minX);assert.equal(bounds.depth,bounds.maxZ-bounds.minZ);
 assert.throws(()=>edit(s,d=>addTent(d)));assert.deepEqual(s,before);
});
