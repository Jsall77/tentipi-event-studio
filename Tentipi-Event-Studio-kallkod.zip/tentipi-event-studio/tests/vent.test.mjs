import test from 'node:test';
import assert from 'node:assert/strict';
import {CANOPY,canopyPoint,ventPoint} from '../src/canopy.mjs';
import {defaultState,normalize,encode,decode,textSummary,ENTRANCE_BAY} from '../src/model.mjs';
test('vent opening is actual clearance above the roof neck and closes with overlap',()=>{
 for(let k=0;k<=36;k++){
  const u=k/36,closed=ventPoint(false,u,1),open=ventPoint(true,u,1);
  assert.ok(closed[1]<CANOPY.bodyTop);
  assert.ok(open[1]>CANOPY.bodyTop+.15);
  assert.ok(Math.hypot(closed[0],closed[2])>CANOPY.topRadius+.1);
  assert.equal(ventPoint(false,u,0)[1],6.8);
  assert.deepEqual(ventPoint(true,u,0),ventPoint(false,u,0));
  for(const progress of[0,.25,.5,.75,1]){assert.deepEqual(ventPoint(progress,u,0),ventPoint(0,u,0));for(let j=0;j<=100;j++){const p=ventPoint(progress,u,j/100);assert.ok(p.every(Number.isFinite));assert.ok(p[1]<=CANOPY.peak+1e-10);}}
  assert.ok(open[1]-closed[1]>.35);
 }
 const neck=canopyPoint(Array(9).fill('down'),0,.5,0);
 assert.equal(neck[1],CANOPY.bodyTop);
 assert.ok(Math.hypot(neck[0],neck[2])>.4);
});
test('ventilation choice persists in share links and is included in the request',()=>{
 for(const ventOpen of[false,true]){
  const s={...defaultState(),ventOpen};
  assert.equal(decode(encode(s)).ventOpen,ventOpen);
  assert.ok(textSummary(s).includes('Ventilation upptill: '+(ventOpen?'öppen':'stängd')));
 }
 const old=defaultState();delete old.ventOpen;
 assert.equal(normalize(old).ventOpen,true);
});

test('canvas entrance persists independently of WallFlex doors and describes raised free passage',()=>{
 for(const entranceOpen of[false,true]){
  const s=defaultState();s.walls[ENTRANCE_BAY]='down';s.entranceOpen=entranceOpen;
  assert.equal(decode(encode(s)).entranceOpen,entranceOpen);
  assert.ok(textSummary(s).includes('Dragkedjeentré, sida 4: '+(entranceOpen?'öppen':'stängd')));
  s.walls[ENTRANCE_BAY]='open';assert.ok(textSummary(s).includes('fri passage under uppfällt brätte'));
 }
 const old=defaultState();delete old.entranceOpen;assert.equal(normalize(old).entranceOpen,true);
});
