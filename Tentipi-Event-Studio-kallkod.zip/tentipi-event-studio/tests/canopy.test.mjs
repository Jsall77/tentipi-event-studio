import test from 'node:test';
import assert from 'node:assert/strict';
import {CANOPY,canopyLift,canopyProfile,canopyPoint,canopyHeightAtRadius,planHalfExtents} from '../src/canopy.mjs';
import {bayAngle} from '../src/model.mjs';

const epsilon=1e-9;
const close=(actual,expected,message='')=>assert.ok(Math.abs(actual-expected)<epsilon,`${message}: ${actual} ≠ ${expected}`);
const patterns=Array.from({length:512},(_,mask)=>Array.from({length:9},(_,i)=>mask&(1<<i)?'open':'down'));
const radial=(radius,height,angle)=>[Math.sin(angle)*radius,height,Math.cos(angle)*radius];

// Every binary raised/lowered arrangement includes the wraparound seam between
// sections nine and one, not only adjacent sections in the middle of the array.
test('all 512 raised/lowered combinations share every canopy seam',()=>{
 for(let mask=0;mask<patterns.length;mask++){
  const walls=patterns[mask];
  for(let i=0;i<9;i++)for(let j=0;j<=32;j++){
   const v=j/32,a=canopyPoint(walls,i,1,v),b=canopyPoint(walls,(i+1)%9,0,v);
   for(let axis=0;axis<3;axis++)close(a[axis],b[axis],`pattern ${mask}, seam ${i+1}→${(i+1)%9+1}, v ${v}, axis ${axis}`);
  }
 }
});

test('all canopy combinations produce finite coordinates and bounded lifts',()=>{
 for(const walls of patterns)for(let i=0;i<9;i++)for(let k=0;k<=8;k++){
  const u=k/8,lift=canopyLift(walls,i,u);
  assert.ok(Number.isFinite(lift)&&lift>=0&&lift<=1);
  for(const v of [0,.16,.32,.48,.639,.64,.641,.8,1])assert.ok(canopyPoint(walls,i,u,v).every(Number.isFinite));
 }
});

test('raised roof hems follow the exact straight chord used by WallFlex',()=>{
 for(const walls of patterns)for(let i=0;i<9;i++){
  if(walls[i]==='down')continue;
  const a=bayAngle(i)-CANOPY.halfAngle,b=bayAngle(i)+CANOPY.halfAngle;
  const A=radial(CANOPY.raisedRadius,CANOPY.raisedHem,a),B=radial(CANOPY.raisedRadius,CANOPY.raisedHem,b);
  const dx=B[0]-A[0],dz=B[2]-A[2],lengthSquared=dx*dx+dz*dz;
  for(let k=0;k<=12;k++){
   const P=canopyPoint(walls,i,k/12,1),px=P[0]-A[0],pz=P[2]-A[2];
   close(P[1],CANOPY.raisedHem,'WallFlex roof height');
   close(px*dz-pz*dx,0,'Roof hem lies on wall chord');
   const along=(px*dx+pz*dz)/lengthSquared;
   assert.ok(along>=-epsilon&&along<=1+epsilon,'Hem remains between the wall corners');
  }
 }
});

test('uniform all-up and all-down tents retain their stated outer corner extents',()=>{
 for(const mode of ['open','down']){
  const walls=Array(9).fill(mode),R=mode==='down'?CANOPY.closedRadius:CANOPY.raisedRadius,Y=mode==='down'?CANOPY.closedHem:CANOPY.raisedHem;
  for(let i=0;i<9;i++)for(const u of [0,.5,1]){
   const p=canopyPoint(walls,i,u,1);
   close(Math.hypot(p[0],p[2]),R*(u===.5?Math.cos(CANOPY.halfAngle):1));
   close(p[1],Y);
  }
  close(canopyProfile(mode==='down'?0:1,0).y,CANOPY.peak);
  close(canopyProfile(mode==='down'?0:1,.64).r,CANOPY.kneeRadius);
 }
});

test('mixed-boundary blending retains each section own centre setting',()=>{
 for(const walls of patterns)for(let i=0;i<9;i++){
  const raised=walls[i]!=='down';
  close(canopyLift(walls,i,.5),raised?1:0);
  close(canopyPoint(walls,i,.5,1)[1],raised?CANOPY.raisedHem:CANOPY.closedHem);
  close(canopyLift(walls,i,0),walls[i]!=='down'||walls[(i+8)%9]!=='down'?1:0);
  close(canopyLift(walls,i,1),walls[i]!=='down'||walls[(i+1)%9]!=='down'?1:0);
 }
});

test('open, window and canvas have identical raised-canopy geometry',()=>{
 const base=['down','open','down','open','down','open','down','down','open'];
 for(const mode of ['window','canvas']){
  const walls=base.map(x=>x==='open'?mode:x);
  for(let i=0;i<9;i++)for(const u of [0,.25,.5,.75,1])for(const v of [0,.32,.64,.8,1]){
   const a=canopyPoint(base,i,u,v),b=canopyPoint(walls,i,u,v);
   a.forEach((value,axis)=>close(value,b[axis]));
  }
 }
});

test('plan view fits full raised diameter and maintains viewport aspect even when narrow',()=>{
 for(const aspect of [.01,.1,.3,.6,.738,.739,1,1.5,2,4]){
  const {x,y}=planHalfExtents(aspect);
  assert.ok(Number.isFinite(x)&&Number.isFinite(y));
  assert.ok(x>=CANOPY.raisedRadius+1.25&&y>=CANOPY.raisedRadius+1.25,'Tent and guy ropes stay inside plan bounds');
  close(x/y,aspect,'Orthographic dimensions preserve aspect');
 }
});

test('lighting roof-height sampling matches the actual canopy surface',()=>{
 // Covers both sides of the knee and every lift transition. Height must be
 // measured on the same roof mesh rather than a second independent cone.
 for(const walls of patterns)for(let i=0;i<9;i++)for(const u of [0,.25,.5,.75,1])for(const v of [.05,.3,.639,.64,.641,.8,.95]){
  const p=canopyPoint(walls,i,u,v),radius=Math.hypot(p[0],p[2]);
  close(canopyHeightAtRadius(walls,i,u,radius),p[1],`Lighting height section ${i+1}`);
 }
});
