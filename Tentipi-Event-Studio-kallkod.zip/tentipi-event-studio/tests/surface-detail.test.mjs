import test from 'node:test';
import assert from 'node:assert/strict';
import {clothRelief} from '../src/surface-detail.mjs';
import {UNDERLAY_CLEARANCE} from '../src/connections.mjs';
test('visual cloth relief cannot reopen shared seams or expose an underlaid connector',()=>{
 for(let bay=0;bay<9;bay++)for(let n=0;n<=100;n++){
  const t=n/100;
  for(const [u,v]of[[0,t],[1,t],[t,0],[t,1]])assert.ok(Math.abs(clothRelief(u,v,bay))<1e-12);
  for(let k=0;k<=100;k++){const offset=clothRelief(t,k/100,bay);assert.ok(Number.isFinite(offset));assert.ok(Math.abs(offset)<=.018);assert.ok(Math.abs(offset)<UNDERLAY_CLEARANCE/3);}
 }
});
