import test from 'node:test';
import assert from 'node:assert/strict';
import * as T from 'three';
import {defaultState,editedState} from '../src/model.mjs';
import {presetLayout,tentEntries,moveTent} from '../src/layout.mjs';
import {canopyPoint} from '../src/canopy.mjs';
import {coveringRoofHeight,underlayHeight,UNDERLAY_CLEARANCE} from '../src/connections.mjs';
import {drawConnections} from '../src/layout-scene.mjs';
function roofMesh(t){const root=new T.Group();for(let i=0;i<9;i++){const pos=[],ix=[],nu=12,nv=24;for(let j=0;j<=nv;j++)for(let k=0;k<=nu;k++){pos.push(...canopyPoint(t.config.walls,i,k/nu,j/nv));if(j<nv&&k<nu){const n=j*(nu+1)+k;ix.push(n,n+1,n+nu+1,n+1,n+nu+2,n+nu+1);}}const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(pos,3));g.setIndex(ix);root.add(new T.Mesh(g,new T.MeshBasicMaterial({side:T.DoubleSide})));}root.position.set(t.x,0,t.z);root.rotation.y=-t.rotation*Math.PI/180;return root;}
for(const name of['pair','triangle','six'])test(`${name}: the connector is hidden below the actual tent roof from above`,()=>{
 let state=editedState(defaultState(),s=>presetLayout(s,name));state=editedState(state,s=>moveTent(s,'t1',s.site.tents[0].x+2,s.site.tents[0].z-1,25));const entries=tentEntries(state),roofs=new T.Group(),links=new T.Group();entries.forEach(t=>roofs.add(roofMesh(t)));drawConnections(T,links,state,null);roofs.updateMatrixWorld(true);links.updateMatrixWorld(true);const ray=new T.Raycaster(),covers=[];links.traverse(m=>{if(m.userData.connectionRoof)covers.push(m)});assert.ok(covers.length>=state.site.links.length);let checked=0;
 for(const mesh of covers){const pos=mesh.geometry.getAttribute('position'),ix=mesh.geometry.index;for(let k=0;k<ix.count;k+=Math.max(3,Math.floor(ix.count/90/3)*3)){const ids=[ix.getX(k),ix.getX(k+1),ix.getX(k+2)],p=new T.Vector3();for(const id of ids)p.add(new T.Vector3(pos.getX(id),pos.getY(id),pos.getZ(id)));p.multiplyScalar(1/3);const y=underlayHeight(entries,p.x,p.z),roof=coveringRoofHeight(entries,p.x,p.z);assert.notEqual(y,null);assert.ok(y<roof-.025);ray.set(new T.Vector3(p.x,20,p.z),new T.Vector3(0,-1,0));const hit=ray.intersectObject(roofs,true)[0];assert.ok(hit,`no original canvas above ${p.toArray()}`);assert.ok(hit.point.y>p.y+.01,`connector protrudes through original rendered canvas: roof=${hit.point.y}, connector=${p.y}`);checked++;}}
 assert.ok(checked>30,'real connector area must remain, not just a hidden/empty object');
});
test('underlay uses the lower overlapping roof and never fabricates coverage outside tents',()=>{
 const s=editedState(defaultState(),d=>presetLayout(d,'pair')),entries=tentEntries(s),x=(entries[0].x+entries[1].x)/2,z=0,roof=coveringRoofHeight(entries,x,z);assert.ok(roof>2);assert.ok(Math.abs(roof-underlayHeight(entries,x,z)-UNDERLAY_CLEARANCE)<1e-10);assert.equal(underlayHeight(entries,100,100),null);
});
