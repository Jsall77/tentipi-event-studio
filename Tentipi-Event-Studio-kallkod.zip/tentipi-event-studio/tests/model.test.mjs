import test from 'node:test';
import assert from 'node:assert/strict';
import {defaultState,normalize,encode,decode,bill,issues,overlaps,corners,textSummary,preset} from '../src/model.mjs';

const item=(type='table200',id='test1',x=0,z=0,rotation=0)=>({id,type,x,z,rotation});
const stateWith=(items=[])=>({...defaultState(),items});
const wallState=(walls)=>({...stateWith(),walls,doors:Array(9).fill(false),floor:false,lights:false});
const endCount=s=>bill(s).find(r=>r.name.includes('ändutfyllnad'))?.qty??0;

test('normalization strips unknown fields, copies arrays, and canonicalizes rotations',()=>{
 const original={...stateWith([item('table200','a',1,-2,-375)]),email:'customer@example.com',serverToken:'not-exported'};
 const output=normalize(original);
 assert.equal(output.items[0].rotation,345);
 assert.equal('email' in output,false);
 assert.equal('serverToken' in output,false);
 output.walls[0]='down';output.items[0].x=5;
 assert.equal(original.walls[0],'open');assert.equal(original.items[0].x,1);
});

test('hostile and malformed projects are rejected before rendering',()=>{
 for(const input of [null,{}, {...stateWith(),version:99},{...stateWith(),fabric:'<script>'}, {...stateWith(),walls:Array(8).fill('open')}, {...stateWith(),walls:Array(10).fill('open')}, {...stateWith(),walls:['door',...Array(8).fill('open')]}, {...stateWith(),items:Array.from({length:91},(_,i)=>item('table200','a'+i))}])assert.throws(()=>normalize(input));
 for(const type of ['unknown','__proto__','constructor','toString'])assert.throws(()=>normalize(stateWith([item(type)])),`Inherited/unknown catalog key ${type} must be rejected`);
 for(const id of ['', '<img onerror=alert(1)>','a'.repeat(33)])assert.throws(()=>normalize(stateWith([item('table200',id)])));
 assert.throws(()=>normalize(stateWith([item('table200','same'),item('bench200','same')])));
 for(const bad of [NaN,Infinity,-Infinity,'1',null])for(const axis of ['x','z','rotation'])assert.throws(()=>normalize(stateWith([{...item(),[axis]:bad}])));
 assert.throws(()=>normalize(stateWith([item('table200','a',15.001)])));
 assert.throws(()=>normalize(stateWith([item('table200','a',0,0,3601)])));
});

test('door opening cannot survive on a lowered or unenclosed bay',()=>{
 const s=normalize({...wallState(['open','down','window','canvas','open','down','window','canvas','open']),doors:Array(9).fill(true)});
 assert.deepEqual(s.doors,[false,false,true,true,false,false,true,true,false]);
 assert.equal(s.doors.length,9);
});

test('share link roundtrip preserves every configuration choice and placement',()=>{
 const s=normalize({...wallState(['down','window','canvas','open','window','canvas','down','open','canvas']),fabric:'white',doors:[true,true,false,false,true,true,false,false,true],floor:true,lights:true,items:[item('table150','tab_1',1.25,-2.5,90),item('bench150','bench-2',-1.2,0,345),item('bamse','fire',0,0,15)]});
 const encoded=encode(s);
 assert.match(encoded,/^[A-Za-z0-9_-]+$/);
 assert.deepEqual(decode(encoded),s);
 assert.throws(()=>decode('x'.repeat(24001)));
 for(const malformed of ['%%','not-a-json-project',btoa('{"version":99}')])assert.throws(()=>decode(malformed));
});

test('WallFlex boundary count handles adjacency, mixed material and wraparound',()=>{
 assert.equal(endCount(wallState(Array(9).fill('open'))),0);
 assert.equal(endCount(wallState(Array(9).fill('window'))),0);
 assert.equal(endCount(wallState(['window',...Array(8).fill('down')])),2);
 assert.equal(endCount(wallState(['window','canvas','window',...Array(6).fill('down')])),2);
 assert.equal(endCount(wallState(['window','open','canvas',...Array(6).fill('open')])),4);
 assert.equal(endCount(wallState(['window','canvas',...Array(6).fill('down'),'window'])),2);
 const row=bill(wallState(['window',...Array(8).fill('down')])).find(r=>r.name.includes('ändutfyllnad'));
 assert.match(row.name,/indikativt/);assert.match(row.note,/verifierar/);
});

test('bill groups real products and keeps unknown prices out of the order total',()=>{
 const s={...wallState(['window','canvas','window',...Array(6).fill('open')]),items:[item('table200','a'),item('table200','b',3),item('bench150','c')],floor:true,lights:true};
 const rows=bill(s);
 assert.equal(rows.filter(r=>r.name.startsWith('Stratus 72')).length,1);
 assert.equal(rows.find(r=>r.name==='Fällbart bord 200').qty,2);
 assert.equal(rows.find(r=>r.name.includes('fönster')).qty,2);
 assert.equal(rows.find(r=>r.name.includes('duk')).qty,1);
 assert.equal(rows.find(r=>r.name.includes('Eventmatta')).qty,5);
 assert.ok(rows.every(r=>Number.isInteger(r.qty)&&r.qty>0));
 assert.ok(rows.every(r=>!('price' in r)&&!('total' in r)), 'Unverified quotation prices must not become zero-price order data');
 const summary=textSummary(s,'https://example.com/#config=abc');
 assert.match(summary,/ej bindande order/);
 assert.match(summary,/Slutlig komponentlista, pris/);
 assert.match(summary,/https:\/\/example.com\/#config=abc/);
 assert.doesNotMatch(summary,/\b0 (?:kr|SEK)\b/);
});

test('light adapter and floor dependencies track the chosen options',()=>{
 const s=stateWith();s.floor=false;s.lights=false;
 assert.ok(!bill(s).some(r=>/Eventmatta|Ljusslinge|strömadapter/.test(r.name)));
 s.lights=true;
 assert.equal(bill(s).filter(r=>r.name.includes('strömadapter')).length,1);
 assert.equal(bill(s).filter(r=>r.name.includes('Ljusslinge')).length,1);
 s.lights=false;s.floor=true;
 assert.equal(bill(s).filter(r=>r.name.includes('Eventmatta')).length,1);
 assert.ok(!bill(s).some(r=>r.name.includes('strömadapter')));
});

test('oriented overlap detection works for rotated and separated furniture',()=>{
 assert.equal(overlaps(item(),item('bench200','b',0,0,90)),true);
 assert.equal(overlaps(item(),item('bench200','b',0,3,90)),false);
 assert.equal(overlaps(item('table200','a',0,0,45),item('table200','b',.3,.3,-45)),true);
 assert.equal(overlaps(item('table200','a',0,0,45),item('table200','b',4,0,-45)),false);
 const rotated=corners(item('table200','a',0,0,90));
 assert.ok(Math.abs(rotated[0].x-.35)<1e-10);
 assert.ok(Math.abs(rotated[0].z+.99)<1e-10);
});

test('placement warnings catch both overlap and an outlying footprint',()=>{
 const s=stateWith([item('table200','a'),item('bench200','b'),item('table200','far',6)]);
 const warnings=issues(s);
 assert.ok(warnings.some(v=>v.ids.includes('a')&&v.ids.includes('b')));
 assert.ok(warnings.some(v=>v.ids.includes('far')&&/stommen/.test(v.text)));
 assert.equal(issues(stateWith(preset('dinner'))).length,0);
 assert.equal(issues(stateWith(preset('empty'))).length,0);
});
