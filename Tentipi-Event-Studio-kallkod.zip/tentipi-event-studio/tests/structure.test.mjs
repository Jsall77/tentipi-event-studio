import test from 'node:test';
import assert from 'node:assert/strict';
import {frameAtBoundary,MAIN} from '../src/structure.mjs';
import {defaultState,normalize,encode,decode,editedState} from '../src/model.mjs';
const radius=p=>Math.hypot(p[0],p[2]);
test('lifting console struts end on the main pole above the ground, not on invented outer feet',()=>{
 const walls=Array(9).fill('down');walls[4]='open';
 for(let i=0;i<9;i++){
  const f=frameAtBoundary(walls,i),lifted=i===4||i===5;
  assert.equal(Boolean(f.beam),lifted);
  if(!lifted)continue;
  const [low,high]=f.strut;
  assert.ok(low[1]>.5&&high[1]>low[1]);
  const t=(low[1]-MAIN.footHeight)/(MAIN.topHeight-MAIN.footHeight);
  for(const axis of[0,1,2])assert.ok(Math.abs(low[axis]-(f.main[0][axis]+t*(f.main[1][axis]-f.main[0][axis])))<1e-10);
  assert.ok(Math.abs(radius(low)-radius(high))<1e-10);
 }
});
test('thin lifting supports appear only at raised boundaries and never add extra ground feet',()=>{
 for(const mode of ['down','open','window','canvas']){
  const walls=Array(9).fill(mode),frames=walls.map((_,i)=>frameAtBoundary(walls,i));
  assert.equal(frames.length,9);
  assert.equal(frames.filter(f=>f.strut).length,mode==='down'?0:9);
  for(const f of frames){assert.equal(f.main[0][1],MAIN.footHeight);if(f.strut)assert.ok(f.strut[0][1]>MAIN.footHeight+.4);}
 }
});
test('environment survives share and project edits without changing old project compatibility',()=>{
 for(const environment of['studio','summer','autumn','winter','desert']){
  const s=editedState(defaultState(),s=>s.environment=environment);
  assert.equal(decode(encode(s)).environment,environment);
 }
 const old=defaultState();delete old.environment;assert.equal(normalize(old).environment,'studio');
 assert.throws(()=>normalize({...old,environment:'constructor'}));
});
