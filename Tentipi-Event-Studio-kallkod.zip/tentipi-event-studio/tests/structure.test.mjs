import test from 'node:test';
import assert from 'node:assert/strict';
import {frameAtBoundary,MAIN} from '../src/structure.mjs';
import {defaultState,normalize,encode,decode,editedState} from '../src/model.mjs';
const radius=p=>Math.hypot(p[0],p[2]);
test('loose lifting poles stand vertically on the ground, independently of the sloping main poles',()=>{
 const walls=Array(9).fill('down');walls[4]='open';
 for(let i=0;i<9;i++){
  const f=frameAtBoundary(walls,i),lifted=i===4||i===5;
  assert.equal(Boolean(f.support),lifted);
  if(!lifted)continue;
  const [low,high]=f.support;
  assert.equal(low[1],.03);assert.ok(high[1]>2.2);
  assert.ok(Math.abs(low[0]-high[0])<1e-10);
  assert.ok(Math.abs(low[2]-high[2])<1e-10);
  assert.ok(Math.abs(radius(low)-6.5)<1e-10);
 }
});
test('thin lifting supports follow raised boundaries without duplicated poles at a shared corner',()=>{
 for(const mode of ['down','open','window','canvas']){
  const walls=Array(9).fill(mode),frames=walls.map((_,i)=>frameAtBoundary(walls,i));
  assert.equal(frames.length,9);
  assert.equal(frames.filter(f=>f.support).length,mode==='down'?0:9);
  for(const f of frames)assert.equal(f.main[0][1],MAIN.footHeight);
 }
});
test('environment survives share and project edits without changing old project compatibility',()=>{
 for(const environment of['studio','summer','autumn','winter','desert']){
  const s=editedState(defaultState(),s=>s.environment=environment);
  assert.equal(decode(encode(s)).environment,environment);
 }
 const old=defaultState();delete old.environment;assert.equal(normalize(old).environment,'studio');
 assert.throws(()=>normalize({...old,environment:'constructor'}));
});
