import test from 'node:test';
import assert from 'node:assert/strict';
import {CANOPY,canopyPoint,transitionInfills} from '../src/canopy.mjs';

const modes=['down','open','window','canvas'];
const closed=Array(9).fill('down');
const enclosed=mode=>mode==='window'||mode==='canvas';
const close=(a,b,message='')=>assert.ok(Math.abs(a-b)<1e-9,`${message}: ${a} ≠ ${b}`);
const point=(panel,index)=>panel.points.slice(index*3,index*3+3);
const equalPoint=(a,b,message)=>a.forEach((v,i)=>close(v,b[i],`${message} axis ${i}`));
function wallsAt(i,own,left,right){const walls=Array(9).fill('down');walls[i]=own;walls[(i+8)%9]=left;walls[(i+1)%9]=right;return walls;}
function configurations(){return modes.flatMap(own=>modes.flatMap(left=>modes.flatMap(right=>Array.from({length:9},(_,i)=>({walls:wallsAt(i,own,left,right),i,own,left,right})))));}

test('transition cloth only fills lowered sections beside enclosed WallFlex',()=>{
 for(const {walls,i,own,left,right}of configurations()){
  const ranges=transitionInfills(walls,i).map(p=>[p.lo,p.hi]);
  const expected=own==='down'?[...(enclosed(left)?[[0,.5]]:[]),...(enclosed(right)?[[.5,1]]:[])]:[];
  assert.deepEqual(ranges,expected,`section ${i+1}, ${left}/${own}/${right}`);
 }
});

test('every infill follows the actual curved roof hem and closed footprint ground',()=>{
 for(const {walls,i}of configurations())for(const panel of transitionInfills(walls,i)){
  assert.equal(panel.points.length%6,0);
  const columns=panel.points.length/6;
  assert.ok(columns>2,'A curved hem needs intermediate samples rather than a boundary triangle');
  for(let k=0;k<columns;k++){
   const u=panel.lo+(panel.hi-panel.lo)*k/(columns-1),bottom=point(panel,k*2),top=point(panel,k*2+1);
   equalPoint(top,canopyPoint(walls,i,u,1),`section ${i+1} roof at u=${u}`);
   const expectedBottom=canopyPoint(closed,i,u,1);expectedBottom[1]=.04;
   equalPoint(bottom,expectedBottom,`section ${i+1} ground at u=${u}`);
   assert.ok(top[1]>=bottom[1],'Cloth does not invert below the ground edge');
   const expectedRadius=CANOPY.closedRadius*Math.cos(CANOPY.halfAngle)/Math.cos((u-.5)*CANOPY.halfAngle*2);
   close(Math.hypot(bottom[0],bottom[2]),expectedRadius);
  }
 }
});

test('the infill actually covers the crescent below the lifted curved hem',()=>{
 for(const neighbor of['window','canvas'])for(const side of['left','right']){
  const walls=wallsAt(3,'down',side==='left'?neighbor:'down',side==='right'?neighbor:'down');
  const [panel]=transitionInfills(walls,3),column=Math.floor(panel.points.length/6/2),top=point(panel,column*2+1),bottom=point(panel,column*2);
  assert.ok(top[1]>.5,'Interior cloth reaches the elevated hem, not only the shared boundary');
  assert.ok(Math.hypot(top[0],top[2])>Math.hypot(bottom[0],bottom[2]),'The infill spans the hem’s outward lift');
 }
});

test('all mesh strips contain finite connected triangles with no missing cells',()=>{
 for(const {walls,i}of configurations())for(const panel of transitionInfills(walls,i)){
  assert.ok(panel.points.every(Number.isFinite));
  const columns=panel.points.length/6,vertices=columns*2;
  assert.equal(panel.indices.length,(columns-1)*6);
  assert.ok(panel.indices.every(n=>Number.isInteger(n)&&n>=0&&n<vertices));
  for(let cell=0;cell<columns-1;cell++){
   const triangles=[panel.indices.slice(cell*6,cell*6+3),panel.indices.slice(cell*6+3,cell*6+6)],corners=new Set([cell*2,cell*2+1,cell*2+2,cell*2+3]);
   assert.equal(new Set(triangles.flat()).size,4,'Both triangles cover all four cell corners');
   assert.ok(triangles.flat().every(v=>corners.has(v)),'A cell cannot skip over its neighbor');
   assert.equal(triangles[0].filter(v=>triangles[1].includes(v)).length,2,'Two triangles share a full diagonal');
   for(const triangle of triangles){
    const [a,b,c]=triangle.map(v=>point(panel,v)),ab=b.map((v,k)=>v-a[k]),ac=c.map((v,k)=>v-a[k]),cross=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]];
    assert.ok(Math.hypot(...cross)>1e-10,'Every cloth triangle has positive area');
   }
  }
 }
});

test('two neighboring infill halves meet at the lowered centre without a hole',()=>{
 for(let i=0;i<9;i++)for(const left of['window','canvas'])for(const right of['window','canvas']){
  const walls=wallsAt(i,'down',left,right),[a,b]=transitionInfills(walls,i),last=a.points.length/3-2;
  equalPoint(point(a,last),point(b,0),'Joined ground edge');
  equalPoint(point(a,last+1),point(b,1),'Joined roof edge');
  equalPoint(point(a,last+1),canopyPoint(walls,i,.5,1),'Centre meets lowered canopy');
 }
});

test('wraparound sections nine and one retain the exact roof and boundary seams',()=>{
 for(const [i,left,right]of[[0,'window','down'],[8,'down','canvas']]){
  const walls=wallsAt(i,'down',left,right),[panel]=transitionInfills(walls,i),leftSide=panel.lo===0,column=leftSide?0:panel.points.length/6-1,u=leftSide?0:1,neighbor=(i+(leftSide?8:1))%9;
  equalPoint(point(panel,column*2+1),canopyPoint(walls,neighbor,leftSide?1:0,1),'Wraparound raised hem');
  const bottom=canopyPoint(closed,neighbor,leftSide?1:0,1);bottom[1]=.04;
  equalPoint(point(panel,column*2),bottom,'Wraparound ground seam');
  close(point(panel,column*2+1)[1],CANOPY.raisedHem);
  equalPoint(point(panel,column*2+1),canopyPoint(walls,i,u,1),'Own roof boundary');
 }
});
