import test from 'node:test';
import assert from 'node:assert/strict';
import {defaultState,normalize,editedState,parseCoordinate,duplicateFurniture} from '../src/model.mjs';

test('rejected edits leave both the project and its furniture unchanged',()=>{
 const state=defaultState(),before=structuredClone(state);
 assert.throws(()=>editedState(state,draft=>draft.items[0].x=15.2));
 assert.deepEqual(state,before);
 const next=editedState(state,draft=>draft.items[0].x=2);
 assert.equal(next.items[0].x,2);
 assert.deepEqual(state,before);
});
test('blank coordinates are rejected instead of moving furniture to the origin',()=>{
 for(const input of['',' ','NaN','Infinity','16','-15.01'])assert.throws(()=>parseCoordinate(input));
 for(const input of['0','-15','15','1.25'])assert.equal(parseCoordinate(input),Number(input));
});
test('duplicating imported furniture at the supported edges preserves a valid project',()=>{
 for(const x of[-15,-14.9,0,14.9,15])for(const z of[-15,14.9,15]){
  const state=defaultState();state.items=state.items.slice(0,1);state.items[0].x=x;state.items[0].z=z;
  const clone=duplicateFurniture(state.items[0]);
  assert.notEqual(clone.id,state.items[0].id);
  const next=editedState(state,draft=>draft.items.push(clone));
  assert.equal(normalize(next).items.length,2);
  assert.equal(state.items.length,1);
 }
});
